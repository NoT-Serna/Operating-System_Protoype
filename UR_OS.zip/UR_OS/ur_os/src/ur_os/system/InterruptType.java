/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package ur_os.system;

/**
 *
 * @author pedro.wightman
 */
public enum InterruptType {
    CPU,
    IO,
    SCHEDULER_CPU_TO_RQ,
    SCHEDULER_RQ_TO_CPU,
    
}
